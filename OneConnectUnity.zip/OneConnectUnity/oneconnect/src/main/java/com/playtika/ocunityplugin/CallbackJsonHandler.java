package com.playtika.ocunityplugin;

import org.json.JSONObject;

public interface CallbackJsonHandler {
    void onHandleResult(JSONObject result);
}