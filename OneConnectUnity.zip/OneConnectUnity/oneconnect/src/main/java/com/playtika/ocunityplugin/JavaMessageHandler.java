package com.playtika.ocunityplugin;

public interface JavaMessageHandler {
    void onMessage(String message, String data);
}
